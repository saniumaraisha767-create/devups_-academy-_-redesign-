# DevUps Academy — Class Link API (Task 4)

This folder contains the `backend-class-link` contribution. It uses ES modules and assumes the shared backend is configured with Express and `express.json()` by the server-setup teammate.

## Files to copy into the shared backend

- `backend/src/routes/classLink.routes.js`
- `backend/src/controllers/classLink.controller.js`
- `backend/src/data/classLink.data.js`
- `backend/src/schemas/class-link.schema.json`

## Server integration required

The server-setup teammate should mount the router in `backend/server.js` (or the agreed main server file):

```js
import classLinkRoutes from './src/routes/classLink.routes.js';
app.use('/api/class-link', classLinkRoutes);
```

Also ensure the main Express app has `app.use(express.json())` before mounting the routes.

## Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/class-link` | Live class details, schedules, announcements and access instructions |
| GET | `/api/class-link/schedule` | List class schedules |
| GET | `/api/class-link/announcements` | List instructor announcements |
| POST | `/api/class-link/schedule` | Add a mock class schedule |
| POST | `/api/class-link/announcements` | Add a mock instructor announcement |

## Important notes

- All supplied records are demo placeholders, not official DevUps Academy class details.
- POST requests update in-memory arrays only. Data resets when the backend restarts.
- Authentication/authorization is not implemented here. The team should agree on admin protection before exposing POST endpoints in production.
- No real meeting URL or private contact details have been invented.

## Example POST body: schedule

```json
{
  "title": "Frontend Development",
  "description": "React components and API integration",
  "date": "2026-11-13",
  "startTime": "14:00",
  "endTime": "16:00",
  "timezone": "Africa/Lagos",
  "instructor": "Instructor name",
  "platform": "Google Meet",
  "meetingUrl": null
}
```

## Example POST body: announcement

```json
{
  "title": "Class reminder",
  "message": "Please review the previous lesson before class.",
  "instructor": "Instructor name"
}
```

## Test locally

After the server-setup teammate has configured Express, install dependencies and start the backend from the `backend` directory as required by the team workflow. Then test the endpoints with Postman, Thunder Client, or curl.
