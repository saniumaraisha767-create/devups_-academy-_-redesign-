import {
  classLinkData,
  classSchedules,
  classAnnouncements
} from '../data/classLink.data.js';

const isValidDate = (value) => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
};

const isValidTime = (value) => typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
const isValidHttpUrl = (value) => {
  if (value == null || value === '') return true;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
};

export function getClassLinkOverview(_req, res) {
  return res.status(200).json({
    success: true,
    message: 'Class link information retrieved successfully.',
    data: {
      liveClass: classLinkData.liveClass,
      schedules: classSchedules,
      announcements: classAnnouncements,
      platformAccess: classLinkData.platformAccess
    },
    meta: { isMockData: true }
  });
}

export function getClassSchedules(_req, res) {
  return res.status(200).json({
    success: true,
    data: classSchedules,
    meta: { count: classSchedules.length, isMockData: true }
  });
}

export function getClassAnnouncements(_req, res) {
  return res.status(200).json({
    success: true,
    data: classAnnouncements,
    meta: { count: classAnnouncements.length, isMockData: true }
  });
}

export function createClassSchedule(req, res) {
  const { title, description = '', date, startTime, endTime, timezone = 'Africa/Lagos', instructor, platform = 'Google Meet', meetingUrl = null } = req.body ?? {};
  const errors = [];

  if (typeof title !== 'string' || !title.trim()) errors.push('title is required.');
  if (!isValidDate(date)) errors.push('date must use YYYY-MM-DD format.');
  if (!isValidTime(startTime)) errors.push('startTime must use HH:mm 24-hour format.');
  if (!isValidTime(endTime)) errors.push('endTime must use HH:mm 24-hour format.');
  if (isValidTime(startTime) && isValidTime(endTime) && endTime <= startTime) errors.push('endTime must be later than startTime.');
  if (typeof instructor !== 'string' || !instructor.trim()) errors.push('instructor is required.');
  if (typeof timezone !== 'string' || !timezone.trim()) errors.push('timezone must be a non-empty string.');
  if (!isValidHttpUrl(meetingUrl)) errors.push('meetingUrl must be a valid HTTP or HTTPS URL, or null.');

  if (errors.length) {
    return res.status(400).json({ success: false, message: 'Invalid class schedule.', errors });
  }

  const schedule = {
    id: `class-${Date.now()}`,
    title: title.trim(),
    description: typeof description === 'string' ? description.trim() : '',
    date,
    startTime,
    endTime,
    timezone: timezone.trim(),
    instructor: instructor.trim(),
    platform: typeof platform === 'string' && platform.trim() ? platform.trim() : 'Google Meet',
    meetingUrl: meetingUrl || null,
    status: 'scheduled'
  };

  classSchedules.push(schedule);
  return res.status(201).json({
    success: true,
    message: 'Class schedule created in mock storage.',
    data: schedule,
    meta: { isMockData: true, persistent: false }
  });
}

export function createClassAnnouncement(req, res) {
  const { title, message, instructor } = req.body ?? {};
  const errors = [];
  if (typeof title !== 'string' || !title.trim()) errors.push('title is required.');
  if (typeof message !== 'string' || !message.trim()) errors.push('message is required.');
  if (typeof instructor !== 'string' || !instructor.trim()) errors.push('instructor is required.');

  if (errors.length) {
    return res.status(400).json({ success: false, message: 'Invalid announcement.', errors });
  }

  const announcement = {
    id: `announcement-${Date.now()}`,
    title: title.trim(),
    message: message.trim(),
    instructor: instructor.trim(),
    publishedAt: new Date().toISOString()
  };

  classAnnouncements.unshift(announcement);
  return res.status(201).json({
    success: true,
    message: 'Announcement created in mock storage.',
    data: announcement,
    meta: { isMockData: true, persistent: false }
  });
}
