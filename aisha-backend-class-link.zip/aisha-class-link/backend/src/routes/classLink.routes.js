import { Router } from 'express';
import {
  getClassLinkOverview,
  getClassSchedules,
  getClassAnnouncements,
  createClassSchedule,
  createClassAnnouncement
} from '../controllers/classLink.controller.js';

const router = Router();

// Mount this router in server.js at /api/class-link.
router.get('/', getClassLinkOverview);
router.get('/schedule', getClassSchedules);
router.get('/announcements', getClassAnnouncements);
router.post('/schedule', createClassSchedule);
router.post('/announcements', createClassAnnouncement);

export default router;
