// Clearly labelled mock data for the Class Link API.
// Replace these examples with approved project data when it becomes available.

export const classLinkData = {
  liveClass: {
    title: 'DevUps Academy Live Class (Demo)',
    meetingUrl: null, // Add the real meeting URL when the instructor provides it.
    platform: 'Google Meet',
    status: 'not_scheduled',
    note: 'The live meeting link has not been provided yet.'
  },
  schedules: [
    {
      id: 'class-demo-001',
      title: 'Web Development Session (Demo)',
      description: 'Sample schedule only; confirm the actual timetable with the instructor.',
      date: '2026-11-13',
      startTime: '14:00',
      endTime: '16:00',
      timezone: 'Africa/Lagos',
      instructor: 'Instructor name to be confirmed',
      platform: 'Google Meet',
      meetingUrl: null,
      status: 'scheduled'
    }
  ],
  announcements: [
    {
      id: 'announcement-demo-001',
      title: 'Class information (Demo)',
      message: 'This is placeholder content. Check with your instructor for official class announcements.',
      publishedAt: '2026-11-11T12:00:00.000Z',
      instructor: 'DevUps Academy'
    }
  ],
  platformAccess: {
    platform: 'Google Meet',
    instructions: [
      'Use the meeting link shared by your instructor.',
      'Sign in with the Google account approved for the class.',
      'Join a few minutes before the scheduled start time.'
    ],
    supportContact: null
  }
};

// In-memory mock storage. New records disappear when the server restarts.
export const classSchedules = [...classLinkData.schedules];
export const classAnnouncements = [...classLinkData.announcements];
